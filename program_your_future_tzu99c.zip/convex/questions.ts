import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { Doc, Id } from "./_generated/dataModel";
import { api } from "./_generated/api";

// Helper functions
function calculatePersonality(avgScore: number): string {
  if (avgScore > 2.5) return "Not Interested";
  if (avgScore > 1.5) return "Undecided";
  return "Interested in Programming";
}

function calculatePoints(avgScore: number, streak: number = 1): number {
  const basePoints = 100; // Base points for completing a quiz
  const accuracyBonus = Math.round((3 - avgScore) * 50); // Up to 150 bonus points for accuracy
  const streakBonus = Math.min(streak * 10, 50); // Up to 50 bonus points for streak
  return basePoints + accuracyBonus + streakBonus;
}

function calculateRank(points: number): string {
  if (points >= 10000) return "Legendary Developer";
  if (points >= 5000) return "Master Developer";
  if (points >= 2500) return "Senior Developer";
  if (points >= 1000) return "Developer";
  if (points >= 500) return "Junior Developer";
  if (points >= 250) return "Code Enthusiast";
  if (points >= 100) return "Code Apprentice";
  return "Code Novice";
}

function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
}

// Exported functions
export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("questions").withIndex("by_order").collect();
  },
});

export const getAllResponses = query({
  args: {},
  handler: async (ctx) => {
    const responses = await ctx.db.query("responses").collect();
    return responses
      .filter((r) => r.completed)
      .map((r) => ({
        ...r,
        score: r.score ?? 0,
      }));
  },
});

export const getLastResponse = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("responses")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .first();
  },
});

export const getLeaderboard = query({
  args: {},
  handler: async (ctx) => {
    const responses = await ctx.db.query("responses").collect();

    // Group responses by user and count them
    const userStats = new Map<Id<"users">, { 
      points: number,
      personality: string,
      rank: string
    }>();
    
    for (const response of responses) {
      if (response.completed) {
        const currentStats = userStats.get(response.userId) ?? { 
          points: 0,
          personality: response.personality,
          rank: "Code Novice"
        };
        
        userStats.set(response.userId, {
          points: currentStats.points + (response.points ?? 0),
          personality: response.personality, // Use the latest personality
          rank: calculateRank(currentStats.points + (response.points ?? 0))
        });
      }
    }

    const profiles = await Promise.all(
      Array.from(userStats.keys()).map((userId) =>
        ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", userId))
          .first()
      )
    );

    const leaderboard = Array.from(userStats.entries()).map(([userId, stats], i) => {
      const profile = profiles[i];
      return {
        name: profile?.name ?? "Anonymous",
        personality: stats.personality,
        points: stats.points,
        rank: stats.rank
      };
    });

    return leaderboard.sort((a, b) => b.points - a.points).slice(0, 10);
  },
});

export const saveResponse = mutation({
  args: {
    answers: v.array(
      v.object({
        questionId: v.id("questions"),
        response: v.number(),
      })
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const score = args.answers.reduce((sum, a) => sum + a.response, 0);
    const avgScore = score / args.answers.length;
    const personality = calculatePersonality(avgScore);
    const percentage = ((3 - avgScore) / 2) * 100;

    // Calculate streak
    const previousResponses = await ctx.db
      .query("responses")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    let streak = 1;
    if (previousResponses.length > 0) {
      const lastResponse = previousResponses[0];
      const lastResponseDate = new Date(lastResponse._creationTime);
      const today = new Date();
      if (isSameDay(today, lastResponseDate)) {
        streak = (lastResponse.streak ?? 1) + 1;
      }
    }

    const points = calculatePoints(avgScore, streak);

    // Save response
    await ctx.db.insert("responses", {
      userId,
      answers: args.answers,
      personality,
      score: avgScore,
      completed: true,
      points,
      streak,
    });

    // Update profile points and rank
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!profile) return { personality, newBadges: [] };

    const totalPoints = (profile.points ?? 0) + points;
    const rank = calculateRank(totalPoints);

    await ctx.db.patch(profile._id, {
      points: totalPoints,
      rank,
    });

    // Handle badges
    const badges = await ctx.db.query("badges").collect();
    const responses = await ctx.db
      .query("responses")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const completions = responses.filter(r => r.completed).length;

    const earnedBadges = badges
      .filter(
        (badge) =>
          (badge.type === "score" &&
            badge.requiredScore !== undefined &&
            percentage >= badge.requiredScore) ||
          (badge.type === "completions" &&
            badge.requiredCompletions !== undefined &&
            completions >= badge.requiredCompletions)
      )
      .map((badge) => badge.name);

    const existingBadges = new Set(profile.badges ?? []);
    const newBadges = earnedBadges.filter((badge) => !existingBadges.has(badge));

    if (newBadges.length > 0) {
      const updatedBadges = [...(Array.isArray(profile.badges) ? profile.badges : []), ...newBadges];
      await ctx.db.patch(profile._id, {
        badges: updatedBadges,
      });
    }

    return { personality, newBadges, points, totalPoints, rank };
  },
});

export const addQuestions = mutation({
  args: {},
  handler: async (ctx) => {
    const existingQuestions = await ctx.db.query("questions").collect();
    for (const question of existingQuestions) {
      await ctx.db.delete(question._id);
    }

    const questions = [
      { text_ar: "هل تستمتع بحل المشكلات المنطقية؟", text_en: "Do you enjoy solving logical problems?", order: 0 },
      { text_ar: "هل أنت مهتم بكيفية عمل التكنولوجيا؟", text_en: "Are you interested in how technology works?", order: 1 },
      { text_ar: "هل تفضل إنشاء حلول جديدة للمشكلات؟", text_en: "Do you prefer creating new solutions to problems?", order: 2 },
      { text_ar: "هل تستمتع بتعلم لغات وأدوات جديدة؟", text_en: "Do you enjoy learning new languages and tools?", order: 3 },
      { text_ar: "هل تفضل العمل على المشاريع التقنية؟", text_en: "Do you prefer working on technical projects?", order: 4 },
      { text_ar: "هل تجد متعة في تحسين الحلول؟", text_en: "Do you find joy in improving solutions?", order: 5 },
      { text_ar: "هل أنت مهتم بتحليل البيانات والأنماط؟", text_en: "Are you interested in analyzing data and patterns?", order: 6 },
      { text_ar: "هل تستمتع بالعمل في فريق تقني؟", text_en: "Do you enjoy working in a technical team?", order: 7 },
      { text_ar: "هل تفضل قضاء الوقت في تعلم البرمجة؟", text_en: "Do you prefer spending time learning programming?", order: 8 },
      { text_ar: "هل ترى نفسك تعمل في التقنية في المستقبل؟", text_en: "Do you see yourself working in tech in the future?", order: 9 },
      { text_ar: "هل تستمتع بتجربة التقنيات الجديدة؟", text_en: "Do you enjoy experimenting with new technologies?", order: 10 },
      { text_ar: "هل تفكر في المساهمة في مشاريع المصدر المفتوح؟", text_en: "Do you think about contributing to open source projects?", order: 11 },
      { text_ar: "هل أنت مهتم بتعلم الأمن السيبراني؟", text_en: "Are you interested in learning about cybersecurity?", order: 12 },
      { text_ar: "هل تفكر في إنشاء تطبيقاتك الخاصة؟", text_en: "Do you think about creating your own applications?", order: 13 },
      { text_ar: "هل أنت مهتم بالذكاء الاصطناعي والتعلم الآلي؟", text_en: "Are you interested in AI and machine learning?", order: 14 }
    ];

    for (const question of questions) {
      await ctx.db.insert("questions", question);
    }

    const badges = await ctx.db.query("badges").collect();
    if (badges.length === 0) {
      await ctx.runMutation(api.badges.initializeBadges, {});
    }
  },
});
