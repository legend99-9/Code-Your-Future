import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const initializeBadges = mutation({
  args: {},
  handler: async (ctx) => {
    const existingBadges = await ctx.db.query("badges").collect();
    for (const badge of existingBadges) {
      await ctx.db.delete(badge._id);
    }

    const badges = [
      // Completion Badges
      {
        name: "First Step",
        name_ar: "الخطوة الأولى",
        description: "Completed your first quiz",
        description_ar: "أكملت أول اختبار",
        icon: "🌱",
        requiredCompletions: 1,
        type: "completions",
      },
      {
        name: "Explorer",
        name_ar: "مستكشف",
        description: "Completed 3 quizzes",
        description_ar: "أكملت 3 اختبارات",
        icon: "🎯",
        requiredCompletions: 3,
        type: "completions",
      },
      {
        name: "Dedicated",
        name_ar: "متفاني",
        description: "Completed 5 quizzes",
        description_ar: "أكملت 5 اختبارات",
        icon: "⭐",
        requiredCompletions: 5,
        type: "completions",
      },
      {
        name: "Professional",
        name_ar: "محترف",
        description: "Completed 10 quizzes",
        description_ar: "أكملت 10 اختبارات",
        icon: "🏆",
        requiredCompletions: 10,
        type: "completions",
      },
      {
        name: "Master",
        name_ar: "خبير",
        description: "Completed 25 quizzes",
        description_ar: "أكملت 25 اختبار",
        icon: "👑",
        requiredCompletions: 25,
        type: "completions",
      },
      {
        name: "Legend",
        name_ar: "أسطورة",
        description: "Completed 50 quizzes",
        description_ar: "أكملت 50 اختبار",
        icon: "🌟",
        requiredCompletions: 50,
        type: "completions",
      },
      // Interest Level Badges
      {
        name: "Tech Curious",
        name_ar: "فضولي تقني",
        description: "Showed initial interest in programming",
        description_ar: "أظهرت اهتماماً أولياً بالبرمجة",
        icon: "🔍",
        requiredScore: 60,
        type: "score",
      },
      {
        name: "Tech Enthusiast",
        name_ar: "متحمس تقني",
        description: "Demonstrated strong interest in programming",
        description_ar: "أظهرت اهتماماً قوياً بالبرمجة",
        icon: "💻",
        requiredScore: 75,
        type: "score",
      },
      {
        name: "Future Developer",
        name_ar: "مطور المستقبل",
        description: "Showed exceptional interest in programming",
        description_ar: "أظهرت اهتماماً استثنائياً بالبرمجة",
        icon: "🚀",
        requiredScore: 85,
        type: "score",
      },
      {
        name: "Tech Visionary",
        name_ar: "رؤية تقنية",
        description: "Achieved the highest level of interest",
        description_ar: "حققت أعلى مستوى من الاهتمام",
        icon: "🌠",
        requiredScore: 95,
        type: "score",
      },
      // Special Badges
      {
        name: "Consistent Learner",
        name_ar: "متعلم مستمر",
        description: "Completed quizzes for 3 days in a row",
        description_ar: "أكملت اختبارات لمدة 3 أيام متتالية",
        icon: "📚",
        requiredCompletions: 3,
        type: "streak",
      },
      {
        name: "Tech Explorer",
        name_ar: "مستكشف تقني",
        description: "Tried all different types of questions",
        description_ar: "جربت جميع أنواع الأسئلة المختلفة",
        icon: "🗺️",
        requiredCompletions: 15,
        type: "variety",
      }
    ];

    for (const badge of badges) {
      await ctx.db.insert("badges", badge);
    }
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("badges").collect();
  },
});

export const getUserBadges = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", q => q.eq("userId", userId))
      .first();

    return profile?.badges ?? [];
  },
});

export const getBadgeProgress = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const badges = await ctx.db.query("badges").collect();
    const responses = await ctx.db
      .query("responses")
      .withIndex("by_user", q => q.eq("userId", userId))
      .collect();

    const completedResponses = responses.filter(r => r.completed);
    const completions = completedResponses.length;
    
    // Calculate best score from last 5 attempts
    const recentScores = completedResponses
      .sort((a, b) => (b._creationTime - a._creationTime))
      .slice(0, 5)
      .map(r => ((3 - (r.score ?? 0)) / 2) * 100);
    
    const bestScore = recentScores.length > 0 ? Math.max(...recentScores) : 0;

    // Calculate streak
    let currentStreak = 0;
    if (completedResponses.length > 0) {
      const sortedResponses = completedResponses.sort((a, b) => b._creationTime - a._creationTime);
      const today = new Date();
      let lastDate = new Date(sortedResponses[0]._creationTime);
      
      if (isSameDay(today, lastDate)) {
        currentStreak = 1;
        for (let i = 1; i < sortedResponses.length; i++) {
          const currentDate = new Date(sortedResponses[i]._creationTime);
          const expectedDate = new Date(lastDate);
          expectedDate.setDate(expectedDate.getDate() - 1);
          
          if (isSameDay(currentDate, expectedDate)) {
            currentStreak++;
            lastDate = currentDate;
          } else {
            break;
          }
        }
      }
    }

    return badges.map(badge => {
      let progress = 0;
      if (badge.type === "score" && badge.requiredScore !== undefined) {
        progress = Math.min(100, (bestScore / badge.requiredScore) * 100);
      } else if (badge.type === "completions" && badge.requiredCompletions !== undefined) {
        progress = Math.min(100, (completions / badge.requiredCompletions) * 100);
      } else if (badge.type === "streak" && badge.requiredCompletions !== undefined) {
        progress = Math.min(100, (currentStreak / badge.requiredCompletions) * 100);
      } else if (badge.type === "variety" && badge.requiredCompletions !== undefined) {
        // For variety badges, we look at the total number of unique questions answered
        const uniqueQuestions = new Set(completedResponses.flatMap(r => r.answers.map(a => a.questionId)));
        progress = Math.min(100, (uniqueQuestions.size / badge.requiredCompletions) * 100);
      }
      return { ...badge, progress };
    });
  },
});

function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
}
